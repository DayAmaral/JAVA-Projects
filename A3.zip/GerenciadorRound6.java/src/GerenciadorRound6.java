
import java.util.ArrayList;
import java.util.Scanner;

public class GerenciadorRound6 {

	static class Local {
		String nome;
		int capacidadeMaxima;

		public Local(String nome, int capacidade) {
			this.nome = nome;
			this.capacidadeMaxima = capacidade;
		}

		public String toString() {
			return "Local: " + this.nome + " (Capacidade: " + this.capacidadeMaxima + " pessoas)";
		}
	}

	static class Participante {
		String nome;
		int numero;
		int idade;

		public Participante(String nome, int numero, int idade) {
			this.nome = nome;
			this.numero = numero;

			if (idade > 0) {
				this.idade = idade;
			} else {
				this.idade = 0; // Se for negativa, definimos como 0 para evitar erros.
				System.out.println("Aviso: Idade inválida, foi definida como 0.");
			}
		}

		public String toString() {
			return "Participante #" + this.numero + " - " + this.nome + " (" + this.idade + " anos)";
		}
	}

	static class Desafio {
		String nome;
		int minParticipantes;
		int maxVencedores;
		Local localDaProva;
		ArrayList<String> regras;

		public Desafio(String nome, int min, int max, Local local, ArrayList<String> regras) {
			this.nome = nome;
			this.minParticipantes = min;
			this.maxVencedores = max;
			this.localDaProva = local;
			this.regras = regras;
		}

		public String toString() {
			return "Desafio: " + this.nome + "\n  - " + this.localDaProva.toString() + "\n  - Mínimo de Participantes: "
					+ this.minParticipantes + "\n  - Regras: " + this.regras;
		}
	}

	static Scanner leitor = new Scanner(System.in);

	static ArrayList<Local> listaDeLocais = new ArrayList<>();
	static ArrayList<Participante> listaDeParticipantes = new ArrayList<>();
	static ArrayList<Desafio> listaDeDesafios = new ArrayList<>();

	public static void main(String[] args) {

		listaDeLocais.add(new Local(" Salão metálico com luzes vermelhas pulsantes.", 20));
		listaDeLocais.add(new Local("Plataforma A ", 50));
		listaDeLocais.add(new Local("Arena de Mármore", 2));
		listaDeLocais.add(new Local("Salão de festas com espelhos quebrados e vitrolas antigas.", 16));
		listaDeLocais.add(new Local("Campo abandonado com trincheiras.", 24));

		System.out.println("--- BEM-VINDO AO SISTEMA ROUND6 ---");

		do {
			System.out.println("\n== MENU PRINCIPAL ==");
			System.out.println("1. Gerenciar Desafios");
			System.out.println("2. Gerenciar Participantes");
			System.out.println("3. Ver Locais Cadastrados");
			System.out.println("4. Sair do Sistema");
			System.out.print("--> Digite sua escolha: ");

			int escolha = leitor.nextInt();
			leitor.nextLine();

			switch (escolha) {
			case 1:
				menuDesafios();
				break;
			case 2:
				menuParticipantes();
				break;
			case 3:
				listarLocais();
				break;
			case 4:
				System.out.println("Obrigado por usar o sistema. Até logo!");
				return;
			default:
				System.out.println("Opção inválida! Por favor, tente novamente.");
			}
		} while (true);
	}

	public static void menuDesafios() {
		System.out.println("\n-- Menu Desafios --");
		System.out.println("1. Adicionar Desafio");
		System.out.println("2. Listar Desafios");
		System.out.println("3. Excluir Desafio");
		System.out.println("4. Voltar");
		System.out.print("--> Digite sua escolha: ");
		int escolha = leitor.nextInt();
		leitor.nextLine();

		if (escolha == 1)
			adicionarDesafio();
		else if (escolha == 2)
			listarDesafios();
		else if (escolha == 3)
			excluirDesafio();
	}

	public static void menuParticipantes() {
		System.out.println("\n-- Menu Participantes --");
		System.out.println("1. Adicionar Participante");
		System.out.println("2. Listar Participantes");
		System.out.println("3. Editar Participante");
		System.out.println("4. Excluir Participante");
		System.out.println("5. Voltar");
		System.out.print("--> Digite sua escolha: ");
		int escolha = leitor.nextInt();
		leitor.nextLine();

		if (escolha == 1)
			adicionarParticipante();
		else if (escolha == 2)
			listarParticipantes();
		else if (escolha == 3)
			editarParticipante();
		else if (escolha == 4)
			excluirParticipante();
	}

	public static void adicionarDesafio() {

		if (listaDeDesafios.size() >= 5) {
			System.out.println("ERRO: Limite de 5 desafios já foi atingido!");
			return;
		}

		System.out.print("Nome do novo desafio: ");
		String nome = leitor.nextLine();
		System.out.print("Número MÍNIMO de participantes: ");
		int min = leitor.nextInt();
		leitor.nextLine();
		System.out.print("Número MÁXIMO de vencedores: ");
		int max = leitor.nextInt();
		leitor.nextLine();

		listarLocais();
		System.out.print("Escolha o número do local para este desafio: ");
		int escolhaLocal = leitor.nextInt();
		leitor.nextLine();

		Local localEscolhido = listaDeLocais.get(escolhaLocal - 1);

		if (localEscolhido.capacidadeMaxima < min) {
			System.out.println("ERRO: A capacidade do local (" + localEscolhido.capacidadeMaxima
					+ ") é menor que o mínimo de participantes exigido (" + min + ").");
			return;
		}

		ArrayList<String> regras = new ArrayList<>();
		System.out.println("Digite as regras (uma por linha, digite 'fim' para parar):");
		while (true) {
			String regra = leitor.nextLine();
			if (regra.equalsIgnoreCase("fim")) {
				break;
			}
			regras.add(regra);
		}

		Desafio novoDesafio = new Desafio(nome, min, max, localEscolhido, regras);
		listaDeDesafios.add(novoDesafio);
		System.out.println("Desafio '" + nome + "' cadastrado com sucesso!");
	}

	public static void listarDesafios() {
		System.out.println("\n== LISTA DE DESAFIOS ==");
		if (listaDeDesafios.isEmpty()) {
			System.out.println("Nenhum desafio cadastrado ainda.");
		} else {
			for (Desafio d : listaDeDesafios) {
				System.out.println("--------------------");
				System.out.println(d);
			}
		}
	}

	public static void excluirDesafio() {
		System.out.print("Digite o nome exato do desafio que deseja excluir: ");
		String nomeParaExcluir = leitor.nextLine();

		Desafio desafioParaRemover = null;
		for (Desafio d : listaDeDesafios) {
			if (d.nome.equalsIgnoreCase(nomeParaExcluir)) {
				desafioParaRemover = d;
				break;
			}
		}

		if (desafioParaRemover != null) {
			listaDeDesafios.remove(desafioParaRemover);
			System.out.println("Desafio removido com sucesso!");
		} else {
			System.out.println("Desafio não encontrado.");
		}
	}

	public static void adicionarParticipante() {
		System.out.print("Nome do novo participante: ");
		String nome = leitor.nextLine();
		System.out.print("Número do participante: ");
		int numero = leitor.nextInt();
		leitor.nextLine();
		System.out.print("Idade do participante: ");
		int idade = leitor.nextInt();
		leitor.nextLine();

		Participante novoParticipante = new Participante(nome, numero, idade);
		listaDeParticipantes.add(novoParticipante);
		System.out.println("Participante " + nome + " cadastrado com sucesso!");
	}

	public static void listarParticipantes() {
		System.out.println("\n== LISTA DE PARTICIPANTES ==");
		if (listaDeParticipantes.isEmpty()) {
			System.out.println("Nenhum participante cadastrado ainda.");
		} else {
			for (Participante p : listaDeParticipantes) {
				System.out.println(p);
			}
		}
	}

	public static void editarParticipante() {
		System.out.print("Digite o número do participante que deseja editar: ");
		int numeroParaEditar = leitor.nextInt();
		leitor.nextLine();

		Participante participanteParaEditar = null;
		for (Participante p : listaDeParticipantes) {
			if (p.numero == numeroParaEditar) {
				participanteParaEditar = p;
				break;
			}
		}

		if (participanteParaEditar != null) {
			System.out.print("Digite o novo nome (anterior: " + participanteParaEditar.nome + "): ");
			participanteParaEditar.nome = leitor.nextLine();
			System.out.print("Digite a nova idade (anterior: " + participanteParaEditar.idade + "): ");
			participanteParaEditar.idade = leitor.nextInt();
			leitor.nextLine();
			System.out.println("Participante atualizado com sucesso!");
		} else {
			System.out.println("Participante com número " + numeroParaEditar + " não encontrado.");
		}
	}

	public static void excluirParticipante() {
		System.out.print("Digite o número do participante a excluir: ");
		int numeroParaExcluir = leitor.nextInt();
		leitor.nextLine();

		Participante participanteParaRemover = null;
		for (Participante p : listaDeParticipantes) {
			if (p.numero == numeroParaExcluir) {
				participanteParaRemover = p;
				break;
			}
		}

		if (participanteParaRemover != null) {
			listaDeParticipantes.remove(participanteParaRemover);
			System.out.println("Participante removido com sucesso!");
		} else {
			System.out.println("Participante não encontrado.");
		}
	}

	public static void listarLocais() {
		System.out.println("\n== LOCAIS DISPONÍVEIS ==");

		for (int i = 0; i < listaDeLocais.size(); i++) {
			System.out.println((i + 1) + ". " + listaDeLocais.get(i));
		}

	}

}
